// Wait for DOM to be fully loaded before accessing elements
document.addEventListener('DOMContentLoaded', function() {
  const track = document.getElementById('imageTrack');
  const container = document.querySelector('.gallery-container');
  const imageCards = document.querySelectorAll('.image-card');

  // Touch and drag variables
  let touchStartX = 0;
  let currentTranslate = 0;
  let isDragging = false;
  let startTouchTranslate = 0;

  function updateImageScales() {
    const containerCenter = container.offsetWidth / 2;
    
    imageCards.forEach(card => {
      // Get the card's position relative to the container
      const cardRect = card.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      
      // Calculate distance from card center to container center
      const cardCenter = cardRect.left - containerRect.left + cardRect.width / 2;
      const distance = Math.abs(cardCenter - containerCenter);
      
      // Scale based on how close to center (max scale at center, min at edges)
      const maxDistance = containerCenter;
      const scale = Math.max(1, 1.5 - (distance / maxDistance) * 0.5);
      
      card.style.transform = `scale(${scale})`;
    });
  }

  // Handle touch start
  track.addEventListener('touchstart', (e) => {
    isDragging = true;
    touchStartX = e.touches[0].clientX;
    startTouchTranslate = currentTranslate;
    track.style.cursor = 'grabbing';
  }, false);

  // Handle touch move (drag)
  track.addEventListener('touchmove', (e) => {
    if (!isDragging) return;
    
    const touchCurrentX = e.touches[0].clientX;
    const dragDistance = touchCurrentX - touchStartX;
    const maxScroll = track.scrollWidth - container.offsetWidth;
    
    // Calculate new translation (keep within bounds)
    currentTranslate = Math.max(-maxScroll, Math.min(0, startTouchTranslate + dragDistance));
    track.style.transform = `translateX(${currentTranslate}px)`;
    
    // Update image scales while dragging
    updateImageScales();
  }, false);

  // Handle touch end
  track.addEventListener('touchend', () => {
    isDragging = false;
    track.style.cursor = 'grab';
  }, false);

  // Handle mouse events for desktop (optional, for better UX)
  let mouseDown = false;
  let mouseStartX = 0;
  let startTranslate = 0;

  track.addEventListener('mousedown', (e) => {
    mouseDown = true;
    mouseStartX = e.clientX;
    startTranslate = currentTranslate;
    track.style.cursor = 'grabbing';
  });

  document.addEventListener('mousemove', (e) => {
    if (!mouseDown) return;
    
    const dragDistance = e.clientX - mouseStartX;
    const maxScroll = track.scrollWidth - container.offsetWidth;
    
    currentTranslate = Math.max(-maxScroll, Math.min(0, startTranslate + dragDistance));
    track.style.transform = `translateX(${currentTranslate}px)`;
    
    updateImageScales();
  });

  document.addEventListener('mouseup', () => {
    mouseDown = false;
    track.style.cursor = 'grab';
  });

  // Handle trackpad two-finger swipe (wheel event)
  track.addEventListener('wheel', (e) => {
    // Check if horizontal scroll is intended
    if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
      e.preventDefault();
      
      const maxScroll = track.scrollWidth - container.offsetWidth;
      
      // Move gallery based on trackpad swipe (deltaX is the movement amount)
      currentTranslate = Math.max(-maxScroll, Math.min(0, currentTranslate - e.deltaX));
      track.style.transform = `translateX(${currentTranslate}px)`;
      
      // Update image scales while scrolling
      updateImageScales();
    }
  }, { passive: false });

  // Recalculate if the browser window changes size
  window.addEventListener('resize', updateImageScales);
  
  // Initialize on page load
  updateImageScales();
});
